#include "prison_event_2.h"
#include "ui_prison_event_2.h"

prison_event_2::prison_event_2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::prison_event_2)
{
    ui->setupUi(this);
}

prison_event_2::~prison_event_2()
{
    delete ui;
}

void prison_event_2::on_pushButton_clicked()
{
    this->close();
}

