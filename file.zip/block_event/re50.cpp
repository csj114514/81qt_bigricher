#include "re50.h"
#include "ui_re50.h"

re50::re50(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re50)
{
    ui->setupUi(this);
}

re50::~re50()
{
    delete ui;
}

void re50::on_lineEdit_textEdited(const QString &arg1)
{
    choose_pr=arg1.toInt();
}


void re50::on_pushButton_clicked()
{
    if(choose_pr!=pr_num and choose_pr >= 0 and choose_pr <= 3){
        Map->man[pr_num].coins+=50;
        Map->man[choose_pr].coins+=50;
        if(Map->man[pr_num].coins < 0){
            ndc.Map=Map;
            ndc.city.Map=Map;
            ndc.factory.Map=Map;
            ndc.bank.Map=Map;
            ndc.fresh(pr_num);
            ndc.city.fresh(pr_num);
            ndc.factory.fresh(pr_num);
            ndc.bank.fresh(pr_num);
            ndc.show();
        }
        else{
            sot.city.Map=Map;
            sot.city.fresh(pr_num);
            sot.factory.Map=Map;
            sot.factory.fresh(pr_num);
            sot.bank.Map=Map;
            sot.bank.fresh(pr_num);
            sot.show();
        }
        this->close();
    }
    else{
        wis.show();
    }
}

