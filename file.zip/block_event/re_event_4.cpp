#include "re_event_4.h"
#include "ui_re_event_4.h"

re_event_4::re_event_4(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event_4)
{
    ui->setupUi(this);
}

re_event_4::~re_event_4()
{
    delete ui;
}

void re_event_4::on_pushButton_clicked()
{
    Map->man[pr_num].if_skip_round=true;
    if(Map->man[pr_num].coins < 0){
        ndc.Map=Map;
        ndc.city.Map=Map;
        ndc.factory.Map=Map;
        ndc.bank.Map=Map;
        ndc.fresh(pr_num);
        ndc.city.fresh(pr_num);
        ndc.factory.fresh(pr_num);
        ndc.bank.fresh(pr_num);
        ndc.show();
    }
    else{
        sot.city.Map=Map;
        sot.city.fresh(pr_num);
        sot.factory.Map=Map;
        sot.factory.fresh(pr_num);
        sot.bank.Map=Map;
        sot.bank.fresh(pr_num);
        sot.show();
    }
    this->close();
}

