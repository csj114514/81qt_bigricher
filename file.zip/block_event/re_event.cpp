#include "re_event.h"
#include "ui_re_event.h"
#include<cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

re_event::re_event(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event)
{
    ui->setupUi(this);
}

re_event::~re_event()
{
    delete ui;
}

void re_event::on_pushButton_clicked()
{
    srand((unsigned int)time(NULL));
    rd=rand()%10+1;//生成随机数
    if(rd==1){
        re1.show();
    }
    else if(rd==2){
        re2.show();
    }
    else if(rd==3){
        re3.show();
    }
    else if(rd==4){
        re4.show();
    }
    else if(rd==5){
        re5.show();
    }
    else if(rd==6){
        re6.show();
    }
    else if(rd==7){
        re7.show();
    }
    else if(rd==8){
        re8.show();
    }
    else if(rd==9){
        re9.show();
    }
    else if(rd==10){
        re10.show();
    }
    this->close();
}

