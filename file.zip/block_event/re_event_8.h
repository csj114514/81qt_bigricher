#ifndef RE_EVENT_8_H
#define RE_EVENT_8_H

#include <QWidget>
#include "ui_re50.h"
#include "block_event/re50.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class re_event_8;
}

class re_event_8 : public QWidget
{
    Q_OBJECT

public:
    explicit re_event_8(QWidget *parent = nullptr);
    ~re_event_8();
    re50 r5;
    near_death_choose ndc;
    sell_out sot;

private slots:
    void on_pushButton_clicked();

private:
    Ui::re_event_8 *ui;
};

#endif // RE_EVENT_8_H
