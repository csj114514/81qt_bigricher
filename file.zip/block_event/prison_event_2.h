#ifndef PRISON_EVENT_2_H
#define PRISON_EVENT_2_H

#include <QWidget>

namespace Ui {
class prison_event_2;
}

class prison_event_2 : public QWidget
{
    Q_OBJECT

public:
    explicit prison_event_2(QWidget *parent = nullptr);
    ~prison_event_2();

private slots:
    void on_pushButton_clicked();

private:
    Ui::prison_event_2 *ui;
};

#endif // PRISON_EVENT_2_H
