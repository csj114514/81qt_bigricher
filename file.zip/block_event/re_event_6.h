#ifndef RE_EVENT_6_H
#define RE_EVENT_6_H

#include <QWidget>
#include "ui_bank_event.h"
#include "block_event/bank_event.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class re_event_6;
}

class re_event_6 : public QWidget
{
    Q_OBJECT

public:
    explicit re_event_6(QWidget *parent = nullptr);
    ~re_event_6();
    int pr_num;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Pr_num){
        pr_num=Pr_num;
    }
    bank_event be;

private slots:
    void on_pushButton_clicked();

private:
    Ui::re_event_6 *ui;
};

#endif // RE_EVENT_6_H
