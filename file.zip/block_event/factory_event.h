#ifndef FACTORY_EVENT_H
#define FACTORY_EVENT_H

#include <QWidget>
#include "map.h"
#include "ui_factory_event.h"
#include "ui_lack_of_money.h"
#include "sign_ui/lack_of_money.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"


namespace Ui {
class factory_event;
}

class factory_event : public QWidget
{
    Q_OBJECT

public:
    explicit factory_event(QWidget *parent = nullptr);
    ~factory_event();
    map* Map;int factory_position;int pr_num;bool buyornot=false;lack_of_money lom;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Factory_position,int Pr_num){
        factory_position=Factory_position;
        pr_num=Pr_num;
        ui->position->clear();
        ui->stock->clear();
        ui->position->setText(QString::number(Factory_position));
        ui->stock->setText(QString::number(Map->factory_buy_cost));
    }

private slots:
    void on_checkBox_clicked(bool checked);

    void on_checkBox_2_clicked(bool checked);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::factory_event *ui;
};

#endif // FACTORY_EVENT_H
