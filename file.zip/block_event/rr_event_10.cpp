#include "rr_event_10.h"
#include "ui_rr_event_10.h"

rr_event_10::rr_event_10(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rr_event_10)
{
    ui->setupUi(this);
}

rr_event_10::~rr_event_10()
{
    delete ui;
}

void rr_event_10::on_pushButton_clicked()
{
    be.fresh(pr_num);
    be.show();
    this->close();
}

