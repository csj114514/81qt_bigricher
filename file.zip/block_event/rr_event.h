#ifndef RR_EVENT_H
#define RR_EVENT_H

#include <QWidget>
#include "block_event/rr_event_1.h"
#include "ui_rr_event_1.h"
#include "block_event/rr_event_2.h"
#include "ui_rr_event_2.h"
#include "block_event/rr_event_3.h"
#include "ui_rr_event_3.h"
#include "block_event/rr_event_4.h"
#include "ui_rr_event_4.h"
#include "block_event/rr_event_5.h"
#include "ui_rr_event_5.h"
#include "block_event/rr_event_6.h"
#include "ui_rr_event_6.h"
#include "block_event/rr_event_7.h"
#include "ui_rr_event_7.h"
#include "block_event/rr_event_8.h"
#include "ui_rr_event_8.h"
#include "block_event/rr_event_9.h"
#include "ui_rr_event_9.h"
#include "block_event/rr_event_10.h"
#include "ui_rr_event_10.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class rr_event;
}

class rr_event : public QWidget
{
    Q_OBJECT

public:
    explicit rr_event(QWidget *parent = nullptr);
    ~rr_event();
    int rd;
    rr_event_1 rr1;
    rr_event_2 rr2;
    rr_event_3 rr3;
    rr_event_4 rr4;
    rr_event_5 rr5;
    rr_event_6 rr6;
    rr_event_7 rr7;
    rr_event_8 rr8;
    rr_event_9 rr9;
    rr_event_10 rr10;
    near_death_choose ndc;
    sell_out sot;

private slots:
    void on_pushButton_clicked();

private:
    Ui::rr_event *ui;
};

#endif // RR_EVENT_H
