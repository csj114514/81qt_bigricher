#include "rr_event_6.h"
#include "ui_rr_event_6.h"

rr_event_6::rr_event_6(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rr_event_6)
{
    ui->setupUi(this);
}

rr_event_6::~rr_event_6()
{
    delete ui;
}

void rr_event_6::on_pushButton_clicked()
{
    be.fresh(pr_num);
    be.show();
    this->close();
}

