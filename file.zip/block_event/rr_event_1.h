#ifndef RR_EVENT_1_H
#define RR_EVENT_1_H

#include <QWidget>
#include "map.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class rr_event_1;
}

class rr_event_1 : public QWidget
{
    Q_OBJECT

public:
    explicit rr_event_1(QWidget *parent = nullptr);
    ~rr_event_1();
    map* Map;int pr_num;
    void fresh(int Pr_num){
        pr_num=Pr_num;
    }
    near_death_choose ndc;
    sell_out sot;

private slots:
    void on_pushButton_clicked();

private:
    Ui::rr_event_1 *ui;
};

#endif // RR_EVENT_1_H
