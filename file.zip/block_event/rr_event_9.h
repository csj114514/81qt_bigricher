#ifndef RR_EVENT_9_H
#define RR_EVENT_9_H

#include <QWidget>
#include "ui_rr50.h"
#include "block_event/rr50.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class rr_event_9;
}

class rr_event_9 : public QWidget
{
    Q_OBJECT

public:
    explicit rr_event_9(QWidget *parent = nullptr);
    ~rr_event_9();
    rr50 r5;
    near_death_choose ndc;
    sell_out sot;

private slots:
    void on_pushButton_clicked();

private:
    Ui::rr_event_9 *ui;
};

#endif // RR_EVENT_9_H
