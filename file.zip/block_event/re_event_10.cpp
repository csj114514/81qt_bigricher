#include "re_event_10.h"
#include "ui_re_event_10.h"

re_event_10::re_event_10(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event_10)
{
    ui->setupUi(this);
}

re_event_10::~re_event_10()
{
    delete ui;
}

void re_event_10::on_pushButton_clicked()
{
    r10.show();
    this->close();
}

