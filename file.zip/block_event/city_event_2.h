#ifndef CITY_EVENT_2_H
#define CITY_EVENT_2_H

#include <QWidget>
#include "map.h"
#include "ui_city_event_2.h"
#include "ui_lack_of_money.h"
#include "sign_ui/lack_of_money.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class city_event_2;
}

class city_event_2 : public QWidget
{
    Q_OBJECT

public:
    explicit city_event_2(QWidget *parent = nullptr);
    ~city_event_2();
    map* Map;int city_num;int pr_num;lack_of_money lom;bool yesorno=false;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int City_num,int Pr_num){
        city_num=City_num;
        pr_num=Pr_num;
        ui->citynum->clear();
        ui->cost->clear();
        ui->citynum->setText(QString::number(City_num));
        ui->cost->setText(QString::number(Map->city_bulid_cost[City_num][0]));
    }

private slots:
    void on_checkBox_clicked(bool checked);

    void on_checkBox_2_clicked(bool checked);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::city_event_2 *ui;
};

#endif // CITY_EVENT_2_H
