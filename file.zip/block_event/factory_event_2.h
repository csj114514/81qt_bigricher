#ifndef FACTORY_EVENT_2_H
#define FACTORY_EVENT_2_H

#include <QWidget>
#include "map.h"
#include "ui_factory_event_2.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class factory_event_2;
}

class factory_event_2 : public QWidget
{
    Q_OBJECT

public:
    explicit factory_event_2(QWidget *parent = nullptr);
    ~factory_event_2();
    map* Map;int factory_position;int pr_num;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Factory_position,int Pr_num){
        factory_position=Factory_position;
        pr_num=Pr_num;
        ui->position->clear();
        ui->passtax->clear();
        ui->position->setText(QString::number(Factory_position));
        int cnt=0;
        for(int i=0;i<3;i++){
            if(Map->factory_owner[Map->blocks_num[Factory_position]][i]!=-1){
                cnt++;
            }
        }
        ui->passtax->setText(QString::number((Map->factory_pass_tax)*cnt));
    }

private slots:
    void on_pushButton_clicked();

private:
    Ui::factory_event_2 *ui;
};

#endif // FACTORY_EVENT_2_H
