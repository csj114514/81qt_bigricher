#ifndef RR_EVENT_7_H
#define RR_EVENT_7_H

#include <QWidget>
#include"sign_ui/wrong_input_sign.h"
#include"map.h"
#include"ui_wrong_input_sign.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class rr_event_7;
}

class rr_event_7 : public QWidget
{
    Q_OBJECT

public:
    explicit rr_event_7(QWidget *parent = nullptr);
    ~rr_event_7();
    map* Map;
    int pr_num;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Pr_num){
        pr_num=Pr_num;
    }
    int city_num;
    wrong_input_sign wis;

private slots:
    void on_lineEdit_textEdited(const QString &arg1);

    void on_pushButton_clicked();

private:
    Ui::rr_event_7 *ui;
};

#endif // RR_EVENT_7_H
