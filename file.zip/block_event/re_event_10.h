#ifndef RE_EVENT_10_H
#define RE_EVENT_10_H

#include <QWidget>
#include "ui_re100.h"
#include "block_event/re100.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class re_event_10;
}

class re_event_10 : public QWidget
{
    Q_OBJECT

public:
    explicit re_event_10(QWidget *parent = nullptr);
    ~re_event_10();
    re100 r10;
    near_death_choose ndc;
    sell_out sot;

private slots:
    void on_pushButton_clicked();

private:
    Ui::re_event_10 *ui;
};

#endif // RE_EVENT_10_H
