#include "city_event_2.h"
#include "ui_city_event_2.h"

city_event_2::city_event_2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::city_event_2)
{
    ui->setupUi(this);
}

city_event_2::~city_event_2()
{
    delete ui;
}

void city_event_2::on_checkBox_clicked(bool checked)
{
    yesorno=checked;
}


void city_event_2::on_checkBox_2_clicked(bool checked)
{
    yesorno=!checked;
}


void city_event_2::on_pushButton_clicked()
{
    if(yesorno){
        if(Map->man[pr_num].coins >= Map->city_bulid_cost[city_num][0]){
            Map->man[pr_num].coins-=Map->city_bulid_cost[city_num][0];
            Map->level_of_city[city_num]++;
            Map->city_owner[city_num]=pr_num;
            if(Map->man[pr_num].coins < 0){
                ndc.Map=Map;
                ndc.city.Map=Map;
                ndc.factory.Map=Map;
                ndc.bank.Map=Map;
                ndc.fresh(pr_num);
                ndc.city.fresh(pr_num);
                ndc.factory.fresh(pr_num);
                ndc.bank.fresh(pr_num);
                ndc.show();
            }
            else{
                sot.city.Map=Map;
                sot.city.fresh(pr_num);
                sot.factory.Map=Map;
                sot.factory.fresh(pr_num);
                sot.bank.Map=Map;
                sot.bank.fresh(pr_num);
                sot.show();
            }
            this->close();
        }
        else{
            lom.show();
        }
    }
    else{
        if(Map->man[pr_num].coins < 0){
            ndc.Map=Map;
            ndc.city.Map=Map;
            ndc.factory.Map=Map;
            ndc.bank.Map=Map;
            ndc.fresh(pr_num);
            ndc.city.fresh(pr_num);
            ndc.factory.fresh(pr_num);
            ndc.bank.fresh(pr_num);
            ndc.show();
        }
        else{
            sot.city.Map=Map;
            sot.city.fresh(pr_num);
            sot.factory.Map=Map;
            sot.factory.fresh(pr_num);
            sot.bank.Map=Map;
            sot.bank.fresh(pr_num);
            sot.show();
        }
        this->close();
    }
}


void city_event_2::on_pushButton_2_clicked()
{
    if(Map->man[pr_num].coins < 0){
        ndc.Map=Map;
        ndc.city.Map=Map;
        ndc.factory.Map=Map;
        ndc.bank.Map=Map;
        ndc.fresh(pr_num);
        ndc.city.fresh(pr_num);
        ndc.factory.fresh(pr_num);
        ndc.bank.fresh(pr_num);
        ndc.show();
    }
    else{
        sot.city.Map=Map;
        sot.city.fresh(pr_num);
        sot.factory.Map=Map;
        sot.factory.fresh(pr_num);
        sot.bank.Map=Map;
        sot.bank.fresh(pr_num);
        sot.show();
    }
    this->close();
}

