#include "re_event_8.h"
#include "ui_re_event_8.h"

re_event_8::re_event_8(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event_8)
{
    ui->setupUi(this);
}

re_event_8::~re_event_8()
{
    delete ui;
}

void re_event_8::on_pushButton_clicked()
{
    r5.show();
    this->close();
}

