#include "rr_event_4.h"
#include "ui_rr_event_4.h"

rr_event_4::rr_event_4(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rr_event_4)
{
    ui->setupUi(this);
}

rr_event_4::~rr_event_4()
{
    delete ui;
}

void rr_event_4::on_pushButton_clicked()
{
    Map->man[pr_num].if_extra_round=true;
    if(Map->man[pr_num].coins < 0){
        ndc.Map=Map;
        ndc.city.Map=Map;
        ndc.factory.Map=Map;
        ndc.bank.Map=Map;
        ndc.fresh(pr_num);
        ndc.city.fresh(pr_num);
        ndc.factory.fresh(pr_num);
        ndc.bank.fresh(pr_num);
        ndc.show();
    }
    else{
        sot.city.Map=Map;
        sot.city.fresh(pr_num);
        sot.factory.Map=Map;
        sot.factory.fresh(pr_num);
        sot.bank.Map=Map;
        sot.bank.fresh(pr_num);
        sot.show();
    }
    this->close();
}

