#ifndef RE_EVENT_4_H
#define RE_EVENT_4_H

#include <QWidget>
#include "map.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class re_event_4;
}

class re_event_4 : public QWidget
{
    Q_OBJECT

public:
    explicit re_event_4(QWidget *parent = nullptr);
    ~re_event_4();
    map* Map;int pr_num;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Pr_num){
        pr_num=Pr_num;
    }

private slots:
    void on_pushButton_clicked();

private:
    Ui::re_event_4 *ui;
};

#endif // RE_EVENT_4_H
