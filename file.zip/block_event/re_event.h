#ifndef RE_EVENT_H
#define RE_EVENT_H

#include <QWidget>
#include "ui_re_event_1.h"
#include "block_event/re_event_1.h"
#include "ui_re_event_2.h"
#include "block_event/re_event_2.h"
#include "ui_re_event_3.h"
#include "block_event/re_event_3.h"
#include "ui_re_event_4.h"
#include "block_event/re_event_4.h"
#include "ui_re_event_5.h"
#include "block_event/re_event_5.h"
#include "ui_re_event_6.h"
#include "block_event/re_event_6.h"
#include "ui_re_event_7.h"
#include "block_event/re_event_7.h"
#include "ui_re_event_8.h"
#include "block_event/re_event_8.h"
#include "ui_re_event_9.h"
#include "block_event/re_event_9.h"
#include "ui_re_event_10.h"
#include "block_event/re_event_10.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class re_event;
}

class re_event : public QWidget
{
    Q_OBJECT

public:
    explicit re_event(QWidget *parent = nullptr);
    ~re_event();
    int rd;
    re_event_1 re1;
    re_event_2 re2;
    re_event_3 re3;
    re_event_4 re4;
    re_event_5 re5;
    re_event_6 re6;
    re_event_7 re7;
    re_event_8 re8;
    re_event_9 re9;
    re_event_10 re10;
    near_death_choose ndc;
    sell_out sot;

private slots:
    void on_pushButton_clicked();

private:
    Ui::re_event *ui;
};

#endif // RE_EVENT_H
