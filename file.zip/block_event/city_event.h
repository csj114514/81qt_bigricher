#ifndef CITY_EVENT_H
#define CITY_EVENT_H

#include <QWidget>
#include "map.h"
#include "ui_city_event.h"
#include "ui_lack_of_money.h"
#include "sign_ui/lack_of_money.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class city_event;
}

class city_event : public QWidget
{
    Q_OBJECT

public:
    explicit city_event(QWidget *parent = nullptr);
    ~city_event();
    map* Map;int city_num;int pr_num;bool yesorno=false;lack_of_money lom;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int City_num,int Pr_num){
        city_num=City_num;
        pr_num=Pr_num;
        ui->citynum->clear();
        ui->level->clear();
        ui->next->clear();
        ui->citynum->setText(QString::number(City_num));
        ui->level->setText(QString::number(Map->level_of_city[City_num]));
        if(Map->level_of_city[City_num]!=3){
            ui->next->setText(QString::number(Map->city_bulid_cost[City_num][Map->level_of_city[City_num]+1]));
        }
        else{
            ui->next->setText("已无法再建造房屋");
        }

    }

private slots:
    void on_checkBox_clicked(bool checked);

    void on_checkBox_2_clicked(bool checked);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::city_event *ui;
};

#endif // CITY_EVENT_H
