#include "rr_event.h"
#include "ui_rr_event.h"
#include<cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

rr_event::rr_event(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rr_event)
{
    ui->setupUi(this);
}

rr_event::~rr_event()
{
    delete ui;
}

void rr_event::on_pushButton_clicked()
{
    srand((unsigned int)time(NULL));
    rd=rand()%10+1;//生成随机数
    if(rd==1){
        rr1.show();
    }
    else if(rd==2){
        rr2.show();
    }
    else if(rd==3){
        rr3.show();
    }
    else if(rd==4){
        rr4.show();
    }
    else if(rd==5){
        rr5.show();
    }
    else if(rd==6){
        rr6.show();
    }
    else if(rd==7){
        rr7.show();
    }
    else if(rd==8){
        rr8.show();
    }
    else if(rd==9){
        rr9.show();
    }
    else if(rd==10){
        rr10.show();
    }
    this->close();
}

