#include "city_event_3.h"
#include "ui_city_event_3.h"

city_event_3::city_event_3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::city_event_3)
{
    ui->setupUi(this);
}

city_event_3::~city_event_3()
{
    delete ui;
}

void city_event_3::on_pushButton_clicked()
{
    if(Map->man[pr_num].coins < 0){
        ndc.Map=Map;
        ndc.city.Map=Map;
        ndc.factory.Map=Map;
        ndc.bank.Map=Map;
        ndc.fresh(pr_num);
        ndc.city.fresh(pr_num);
        ndc.factory.fresh(pr_num);
        ndc.bank.fresh(pr_num);
        ndc.show();
    }
    else{
        sot.city.Map=Map;
        sot.city.fresh(pr_num);
        sot.factory.Map=Map;
        sot.factory.fresh(pr_num);
        sot.bank.Map=Map;
        sot.bank.fresh(pr_num);
        sot.show();
    }
    this->close();
}

