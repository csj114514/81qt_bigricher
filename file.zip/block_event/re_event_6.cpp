#include "re_event_6.h"
#include "ui_re_event_6.h"

re_event_6::re_event_6(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event_6)
{
    ui->setupUi(this);
}

re_event_6::~re_event_6()
{
    delete ui;
}

void re_event_6::on_pushButton_clicked()
{
    be.fresh(pr_num);
    be.show();
    this->close();
}

