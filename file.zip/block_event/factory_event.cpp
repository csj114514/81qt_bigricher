#include "factory_event.h"
#include "ui_factory_event.h"

factory_event::factory_event(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::factory_event)
{
    ui->setupUi(this);
}

factory_event::~factory_event()
{
    delete ui;
}

void factory_event::on_checkBox_clicked(bool checked)
{
    buyornot=checked;
}


void factory_event::on_checkBox_2_clicked(bool checked)
{
    buyornot=!checked;
}


void factory_event::on_pushButton_clicked()
{
    if(buyornot){
        if(Map->man[pr_num].coins >= Map->factory_buy_cost){
            Map->man[pr_num].coins-=Map->factory_buy_cost;
            for (int i = 0; i < 3; ++i) {
                if(Map->factory_owner[Map->blocks_num[factory_position]][i]==-1){
                    Map->factory_owner[Map->blocks_num[factory_position]][i]=pr_num;
                    break;
                }
            }
            if(Map->man[pr_num].coins < 0){
                ndc.Map=Map;
                ndc.city.Map=Map;
                ndc.factory.Map=Map;
                ndc.bank.Map=Map;
                ndc.fresh(pr_num);
                ndc.city.fresh(pr_num);
                ndc.factory.fresh(pr_num);
                ndc.bank.fresh(pr_num);
                ndc.show();
            }
            else{
                sot.city.Map=Map;
                sot.city.fresh(pr_num);
                sot.factory.Map=Map;
                sot.factory.fresh(pr_num);
                sot.bank.Map=Map;
                sot.bank.fresh(pr_num);
                sot.show();
            }
            this->close();
        }
        else{
            lom.show();
        }
    }
    else{
        if(Map->man[pr_num].coins < 0){
            ndc.Map=Map;
            ndc.city.Map=Map;
            ndc.factory.Map=Map;
            ndc.bank.Map=Map;
            ndc.fresh(pr_num);
            ndc.city.fresh(pr_num);
            ndc.factory.fresh(pr_num);
            ndc.bank.fresh(pr_num);
            ndc.show();
        }
        else{
            sot.city.Map=Map;
            sot.city.fresh(pr_num);
            sot.factory.Map=Map;
            sot.factory.fresh(pr_num);
            sot.bank.Map=Map;
            sot.bank.fresh(pr_num);
            sot.show();
        }
        this->close();
    }
}


void factory_event::on_pushButton_2_clicked()
{
    if(Map->man[pr_num].coins < 0){
        ndc.Map=Map;
        ndc.city.Map=Map;
        ndc.factory.Map=Map;
        ndc.bank.Map=Map;
        ndc.fresh(pr_num);
        ndc.city.fresh(pr_num);
        ndc.factory.fresh(pr_num);
        ndc.bank.fresh(pr_num);
        ndc.show();
    }
    else{
        sot.city.Map=Map;
        sot.city.fresh(pr_num);
        sot.factory.Map=Map;
        sot.factory.fresh(pr_num);
        sot.bank.Map=Map;
        sot.bank.fresh(pr_num);
        sot.show();
    }
    this->close();
}

