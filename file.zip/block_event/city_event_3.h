#ifndef CITY_EVENT_3_H
#define CITY_EVENT_3_H

#include <QWidget>
#include "map.h"
#include "ui_city_event_3.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class city_event_3;
}

class city_event_3 : public QWidget
{
    Q_OBJECT

public:
    explicit city_event_3(QWidget *parent = nullptr);
    ~city_event_3();
    map* Map;int city_num;int pr_num;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int City_num,int Pr_num){
        city_num=City_num;
        pr_num=Pr_num;
        ui->citynum->clear();
        ui->owner->clear();
        ui->passtax->clear();
        ui->citynum->setText(QString::number(City_num));
        ui->owner->setText(QString::number(Map->city_owner[City_num]));
        ui->passtax->setText(QString::number(Map->city_pass_tax[City_num][Map->level_of_city[City_num]]));
    }

private slots:
    void on_pushButton_clicked();

private:
    Ui::city_event_3 *ui;
};

#endif // CITY_EVENT_3_H
