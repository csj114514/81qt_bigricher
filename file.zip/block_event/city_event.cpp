#include "city_event.h"
#include "ui_city_event.h"

city_event::city_event(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::city_event)
{
    ui->setupUi(this);
}

city_event::~city_event()
{
    delete ui;
}

void city_event::on_checkBox_clicked(bool checked)
{
    yesorno=checked;
}


void city_event::on_checkBox_2_clicked(bool checked)
{
    yesorno=!checked;
}


void city_event::on_pushButton_clicked()
{
    if(yesorno){
        if(Map->level_of_city[city_num] < 3 and Map->man[pr_num].coins >= Map->city_bulid_cost[city_num][Map->level_of_city[city_num]+1]){
            Map->man[pr_num].coins-=Map->city_bulid_cost[city_num][Map->level_of_city[city_num]+1];
            Map->level_of_city[city_num]++;
            if(Map->man[pr_num].coins < 0){
                ndc.Map=Map;
                ndc.city.Map=Map;
                ndc.factory.Map=Map;
                ndc.bank.Map=Map;
                ndc.fresh(pr_num);
                ndc.city.fresh(pr_num);
                ndc.factory.fresh(pr_num);
                ndc.bank.fresh(pr_num);
                ndc.show();
            }
            else{
                sot.city.Map=Map;
                sot.city.fresh(pr_num);
                sot.factory.Map=Map;
                sot.factory.fresh(pr_num);
                sot.bank.Map=Map;
                sot.bank.fresh(pr_num);
                sot.show();
            }
            this->close();
        }
        else if(Map->level_of_city[city_num]==3 and Map->man[pr_num].coins >= Map->city_bulid_cost[city_num][Map->level_of_city[city_num]+1]){
            if(Map->man[pr_num].coins < 0){
                ndc.Map=Map;
                ndc.city.Map=Map;
                ndc.factory.Map=Map;
                ndc.bank.Map=Map;
                ndc.fresh(pr_num);
                ndc.city.fresh(pr_num);
                ndc.factory.fresh(pr_num);
                ndc.bank.fresh(pr_num);
                ndc.show();
            }
            else{
                sot.city.Map=Map;
                sot.city.fresh(pr_num);
                sot.factory.Map=Map;
                sot.factory.fresh(pr_num);
                sot.bank.Map=Map;
                sot.bank.fresh(pr_num);
                sot.show();
            }
            this->close();
        }
        else{
            lom.show();
        }
    }
    else{
        if(Map->man[pr_num].coins < 0){
            ndc.Map=Map;
            ndc.city.Map=Map;
            ndc.factory.Map=Map;
            ndc.bank.Map=Map;
            ndc.fresh(pr_num);
            ndc.city.fresh(pr_num);
            ndc.factory.fresh(pr_num);
            ndc.bank.fresh(pr_num);
            ndc.show();
        }
        else{
            sot.city.Map=Map;
            sot.city.fresh(pr_num);
            sot.factory.Map=Map;
            sot.factory.fresh(pr_num);
            sot.bank.Map=Map;
            sot.bank.fresh(pr_num);
            sot.show();
        }
        this->close();
    }
}


void city_event::on_pushButton_2_clicked()
{
    if(Map->man[pr_num].coins < 0){
        ndc.Map=Map;
        ndc.city.Map=Map;
        ndc.factory.Map=Map;
        ndc.bank.Map=Map;
        ndc.fresh(pr_num);
        ndc.city.fresh(pr_num);
        ndc.factory.fresh(pr_num);
        ndc.bank.fresh(pr_num);
        ndc.show();
    }
    else{
        sot.city.Map=Map;
        sot.city.fresh(pr_num);
        sot.factory.Map=Map;
        sot.factory.fresh(pr_num);
        sot.bank.Map=Map;
        sot.bank.fresh(pr_num);
        sot.show();
    }
    this->close();
}

