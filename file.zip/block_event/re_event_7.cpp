#include "re_event_7.h"
#include "ui_re_event_7.h"

re_event_7::re_event_7(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event_7)
{
    ui->setupUi(this);
}

re_event_7::~re_event_7()
{
    delete ui;
}

void re_event_7::on_pushButton_clicked()
{
    r5.show();
    this->close();
}

