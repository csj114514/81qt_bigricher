#ifndef RE_EVENT_5_H
#define RE_EVENT_5_H

#include <QWidget>
#include "ui_airport_event.h"
#include "block_event/airport_event.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class re_event_5;
}

class re_event_5 : public QWidget
{
    Q_OBJECT

public:
    explicit re_event_5(QWidget *parent = nullptr);
    ~re_event_5();
    airport_event ae;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Pr_num){
        ae.pr_num=Pr_num;
    }

private slots:
    void on_pushButton_clicked();

private:
    Ui::re_event_5 *ui;
};

#endif // RE_EVENT_5_H
