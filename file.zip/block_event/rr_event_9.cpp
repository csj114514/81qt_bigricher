#include "rr_event_9.h"
#include "ui_rr_event_9.h"

rr_event_9::rr_event_9(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rr_event_9)
{
    ui->setupUi(this);
}

rr_event_9::~rr_event_9()
{
    delete ui;
}

void rr_event_9::on_pushButton_clicked()
{
    r5.show();
    this->close();
}

