#include "rr_event_5.h"
#include "ui_rr_event_5.h"

rr_event_5::rr_event_5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rr_event_5)
{
    ui->setupUi(this);
}

rr_event_5::~rr_event_5()
{
    delete ui;
}

void rr_event_5::on_pushButton_clicked()
{
    ae.show();
    this->close();
}

