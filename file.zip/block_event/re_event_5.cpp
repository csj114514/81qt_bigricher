#include "re_event_5.h"
#include "ui_re_event_5.h"

re_event_5::re_event_5(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event_5)
{
    ui->setupUi(this);
}

re_event_5::~re_event_5()
{
    delete ui;
}

void re_event_5::on_pushButton_clicked()
{
    ae.show();
    this->close();
}

