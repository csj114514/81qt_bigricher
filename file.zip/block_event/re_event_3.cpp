#include "re_event_3.h"
#include "ui_re_event_3.h"

re_event_3::re_event_3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_event_3)
{
    ui->setupUi(this);
}

re_event_3::~re_event_3()
{
    delete ui;
}

void re_event_3::on_pushButton_clicked()
{
    be.fresh(pr_num);
    be.show();
    this->close();
}

