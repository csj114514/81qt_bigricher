#include "bank_event.h"
#include "ui_bank_event.h"

bank_event::bank_event(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::bank_event)
{
    ui->setupUi(this);
}

bank_event::~bank_event()
{
    delete ui;
}

void bank_event::on_pushButton_2_clicked()
{
    if(Map->man[pr_num].coins < 0){
        ndc.Map=Map;
        ndc.city.Map=Map;
        ndc.factory.Map=Map;
        ndc.bank.Map=Map;
        ndc.fresh(pr_num);
        ndc.city.fresh(pr_num);
        ndc.factory.fresh(pr_num);
        ndc.bank.fresh(pr_num);
        ndc.show();
    }
    else{
        sot.city.Map=Map;
        sot.city.fresh(pr_num);
        sot.factory.Map=Map;
        sot.factory.fresh(pr_num);
        sot.bank.Map=Map;
        sot.bank.fresh(pr_num);
        sot.show();
    }
    this->close();
}



void bank_event::on_inbox_clicked(bool checked)
{
    inorout=checked;
}


void bank_event::on_outbox_clicked(bool checked)
{
    inorout=!checked;
}


void bank_event::on_moneyget_textEdited(const QString &arg1)
{
    money_change=arg1.toInt();
}


void bank_event::on_pushButton_clicked()
{
    if (inorout) {
        if (money_change<0 || money_change>Map->man[pr_num].coins) {
            w.show();
        }
        else {
            Map->man[pr_num].coins -= money_change;
            Map->man[pr_num].coins_inbank += money_change;
            if(Map->man[pr_num].coins < 0){
                ndc.Map=Map;
                ndc.city.Map=Map;
                ndc.factory.Map=Map;
                ndc.bank.Map=Map;
                ndc.fresh(pr_num);
                ndc.city.fresh(pr_num);
                ndc.factory.fresh(pr_num);
                ndc.bank.fresh(pr_num);
                ndc.show();
            }
            else{
                sot.city.Map=Map;
                sot.city.fresh(pr_num);
                sot.factory.Map=Map;
                sot.factory.fresh(pr_num);
                sot.bank.Map=Map;
                sot.bank.fresh(pr_num);
                sot.show();
            }
            this->close();
        }
    }
    else {
        if (money_change > Map->man[pr_num].coins_inbank || money_change < 0) {
            w.show();
        }
        else {
            Map->man[pr_num].coins += money_change;
            Map->man[pr_num].coins_inbank -= money_change;
            if(Map->man[pr_num].coins < 0){
                ndc.Map=Map;
                ndc.city.Map=Map;
                ndc.factory.Map=Map;
                ndc.bank.Map=Map;
                ndc.fresh(pr_num);
                ndc.city.fresh(pr_num);
                ndc.factory.fresh(pr_num);
                ndc.bank.fresh(pr_num);
                ndc.show();
            }
            else{
                sot.city.Map=Map;
                sot.city.fresh(pr_num);
                sot.factory.Map=Map;
                sot.factory.fresh(pr_num);
                sot.bank.Map=Map;
                sot.bank.fresh(pr_num);
                sot.show();
            }
            this->close();
        }
    }
}

