#ifndef PRISON_EVENT_H
#define PRISON_EVENT_H

#include <QWidget>
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"
#include "map.h"

namespace Ui {
class prison_event;
}

class prison_event : public QWidget
{
    Q_OBJECT

public:
    explicit prison_event(QWidget *parent = nullptr);
    ~prison_event();
    map* Map;int pr_num;
    void fresh(int Pr_num){
        pr_num=Pr_num;
    }
    near_death_choose ndc;
    sell_out sot;

private slots:
    void on_pushButton_clicked();

private:
    Ui::prison_event *ui;
};

#endif // PRISON_EVENT_H
