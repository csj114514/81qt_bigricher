#ifndef AIRPORT_EVENT_H
#define AIRPORT_EVENT_H

#include <QWidget>
#include "map.h"
#include "ui_airport_event.h"
#include "ui_wrong_input_sign.h"
#include "sign_ui/wrong_input_sign.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class airport_event;
}

class airport_event : public QWidget
{
    Q_OBJECT

public:
    explicit airport_event(QWidget *parent = nullptr);
    ~airport_event();
    int dest=16;int tmp;int pr_num;map* Map;
    wrong_input_sign wis;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Pr_num){
        ui->des->clear();
        pr_num=Pr_num;
    }
private slots:
    void on_des_textEdited(const QString &arg1);

    void on_pushButton_clicked();

private:
    Ui::airport_event *ui;
};

#endif // AIRPORT_EVENT_H
