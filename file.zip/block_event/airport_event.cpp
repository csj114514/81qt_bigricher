#include "airport_event.h"
#include "ui_airport_event.h"

airport_event::airport_event(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::airport_event)
{
    ui->setupUi(this);
}

airport_event::~airport_event()
{
    delete ui;
}

void airport_event::on_des_textEdited(const QString &arg1)
{
    tmp=arg1.toInt();
}


void airport_event::on_pushButton_clicked()
{
    dest=tmp;
    if(dest > 31 or dest < 0 or dest==16){
        wis.show();
    }
    else{
        Map->man[pr_num].if_airport=true;
        Map->man[pr_num].position=dest;
        this->close();
    }
}

