#ifndef BANK_EVENT_H
#define BANK_EVENT_H

#include <QWidget>
#include "map.h"
#include "sign_ui/wrong_input_sign.h"
#include "ui_wrong_input_sign.h"
#include "ui_bank_event.h"
#include "ui_near_death_choose.h"
#include "near_death_ui/near_death_choose.h"
#include "ui_sell_out.h"
#include "near_death_ui/sell_out.h"

namespace Ui {
class bank_event;
}

class bank_event : public QWidget
{
    Q_OBJECT

public:
    explicit bank_event(QWidget *parent = nullptr);
    ~bank_event();
    map* Map;int pr_num;int money_change;bool inorout;
    wrong_input_sign w;
    near_death_choose ndc;
    sell_out sot;
    void fresh(int Pr_num){
        pr_num=Pr_num;
        ui->coins->clear();
        ui->coinsinbank->clear();
        ui->moneyget->clear();
        ui->prnum->clear();
        ui->prnum->setText(QString::number(pr_num));
        ui->coins->setText(QString::number(Map->man[pr_num].coins));
        ui->coinsinbank->setText(QString::number(Map->man[pr_num].coins_inbank));
    }

private slots:
    void on_pushButton_2_clicked();

    void on_inbox_clicked(bool checked);

    void on_outbox_clicked(bool checked);

    void on_moneyget_textEdited(const QString &arg1);

    void on_pushButton_clicked();

private:
    Ui::bank_event *ui;
};

#endif // BANK_EVENT_H
