#ifndef LACK_OF_MONEY_H
#define LACK_OF_MONEY_H

#include <QWidget>

namespace Ui {
class lack_of_money;
}

class lack_of_money : public QWidget
{
    Q_OBJECT

public:
    explicit lack_of_money(QWidget *parent = nullptr);
    ~lack_of_money();

private slots:
    void on_pushButton_clicked();

private:
    Ui::lack_of_money *ui;
};

#endif // LACK_OF_MONEY_H
