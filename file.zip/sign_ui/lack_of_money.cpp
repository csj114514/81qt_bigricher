#include "lack_of_money.h"
#include "ui_lack_of_money.h"

lack_of_money::lack_of_money(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::lack_of_money)
{
    ui->setupUi(this);
}

lack_of_money::~lack_of_money()
{
    delete ui;
}

void lack_of_money::on_pushButton_clicked()
{
    this->close();
}

