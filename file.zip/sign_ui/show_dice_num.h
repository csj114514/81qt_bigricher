#ifndef SHOW_DICE_NUM_H
#define SHOW_DICE_NUM_H

#include <QWidget>
#include "ui_show_dice_num.h"

namespace Ui {
class show_dice_num;
}

class show_dice_num : public QWidget
{
    Q_OBJECT

public:
    explicit show_dice_num(QWidget *parent = nullptr);
    ~show_dice_num();
    int dice_num;
    void fresh(){
        ui->dice_number->clear();
        ui->dice_number->setText(QString::number(dice_num));
    }

private slots:
    void on_close_clicked();

private:
    Ui::show_dice_num *ui;
};

#endif // SHOW_DICE_NUM_H
