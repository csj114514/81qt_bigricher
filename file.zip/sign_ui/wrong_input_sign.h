#ifndef WRONG_INPUT_SIGN_H
#define WRONG_INPUT_SIGN_H

#include <QWidget>

namespace Ui {
class wrong_input_sign;
}

class wrong_input_sign : public QWidget
{
    Q_OBJECT

public:
    explicit wrong_input_sign(QWidget *parent = nullptr);
    ~wrong_input_sign();

private slots:
    void on_pushButton_clicked();

private:
    Ui::wrong_input_sign *ui;
};

#endif // WRONG_INPUT_SIGN_H
