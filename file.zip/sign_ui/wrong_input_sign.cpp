#include "wrong_input_sign.h"
#include "ui_wrong_input_sign.h"

wrong_input_sign::wrong_input_sign(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::wrong_input_sign)
{
    ui->setupUi(this);
}

wrong_input_sign::~wrong_input_sign()
{
    delete ui;
}

void wrong_input_sign::on_pushButton_clicked()
{
    this->close();
}

