#include "show_dice_num.h"
#include "ui_show_dice_num.h"

show_dice_num::show_dice_num(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::show_dice_num)
{
    ui->setupUi(this);
}

show_dice_num::~show_dice_num()
{
    delete ui;
}

void show_dice_num::on_close_clicked()
{
    this->close();
}

