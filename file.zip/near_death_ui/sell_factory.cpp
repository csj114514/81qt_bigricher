#include "sell_factory.h"
#include "ui_sell_factory.h"

sell_factory::sell_factory(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sell_factory)
{
    ui->setupUi(this);
}

sell_factory::~sell_factory()
{
    delete ui;
}

void sell_factory::on_fnum_textEdited(const QString &arg1)
{
    f_num=arg1.toInt();
}


void sell_factory::on_pushButton_2_clicked()
{
    this->close();
}


void sell_factory::on_pushButton_clicked()
{
    int flag=0;
    if(f_num<=2&&f_num>=0){
        for(int i=0;i<3;i++){
            if(Map->factory_owner[f_num][i]==pr_num){
                flag=1;
            }
        }
    }
    if(flag){
        Map->man[pr_num].coins+=100;
        for(int i=0;i<3;i++){
            if(Map->factory_owner[f_num][i]==pr_num){
                for(int j=i;j<3;j++){
                    if(j!=2){
                        Map->factory_owner[f_num][j]=Map->factory_owner[f_num][j+1];
                    }
                    else Map->factory_owner[f_num][j]=-1;
                }
                break;
            }
        }
        fresh(pr_num);}
    else{
        w.show();
    }
}

