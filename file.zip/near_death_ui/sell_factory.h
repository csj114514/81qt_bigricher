#ifndef SELL_FACTORY_H
#define SELL_FACTORY_H

#include <QWidget>
#include"map.h"
#include "ui_sell_factory.h"
#include "ui_wrong_input_sign.h"
#include"sign_ui/wrong_input_sign.h"


namespace Ui {
class sell_factory;
}

class sell_factory : public QWidget
{
    Q_OBJECT

public:
    explicit sell_factory(QWidget *parent = nullptr);
    ~sell_factory();
    map* Map;int pr_num;int f_num;
    wrong_input_sign w;
    int num_0,num_1,num_2;
    void fresh(int Pr_num){
        pr_num=Pr_num;
        ui->coins->clear();
        ui->prnum->clear();
        ui->fnum->clear();
        ui->num0->clear();
        ui->num1->clear();
        ui->num2->clear();
        ui->prnum->setText(QString::number(pr_num));
        ui->coins->setText(QString::number(Map->man[pr_num].coins));
        num_0=0;
        for(int i=0;i<3;i++){
            if(Map->factory_owner[0][i]==pr_num)num_0++;
        }
        num_1=0;
        for(int i=0;i<3;i++){
            if(Map->factory_owner[1][i]==pr_num)num_1++;
        }
        num_2=0;
        for(int i=0;i<3;i++){
            if(Map->factory_owner[2][i]==pr_num)num_2++;
        }
        ui->num0->setText((QString::number(num_0)));
        ui->num1->setText((QString::number(num_1)));
        ui->num2->setText((QString::number(num_2)));
    }

private slots:
    void on_fnum_textEdited(const QString &arg1);

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::sell_factory *ui;
};

#endif // SELL_FACTORY_H
