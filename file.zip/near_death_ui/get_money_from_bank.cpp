#include "get_money_from_bank.h"
#include "ui_get_money_from_bank.h"

get_money_from_bank::get_money_from_bank(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::get_money_from_bank)
{
    ui->setupUi(this);
}

get_money_from_bank::~get_money_from_bank()
{
    delete ui;
}

void get_money_from_bank::on_money_got_textEdited(const QString &arg1)
{
    money_get=arg1.toInt();
}


void get_money_from_bank::on_pushButton_2_clicked()
{
    this->close();
}


void get_money_from_bank::on_pushButton_clicked()
{
    if(money_get <= Map->man[pr_num].coins_inbank and money_get >= 0){
        Map->man[pr_num].coins_inbank-=money_get;
        Map->man[pr_num].coins+=(int)((double)(money_get)*0.95);
        fresh(pr_num);
    }
    else{
        w.show();
    }
}

