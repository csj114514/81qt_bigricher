#ifndef SELL_CITY_H
#define SELL_CITY_H

#include <QWidget>
#include"map.h"
#include "ui_sell_city.h"
#include "ui_wrong_input_sign.h"
#include"sign_ui/wrong_input_sign.h"

namespace Ui {
class sell_city;
}

class sell_city : public QWidget
{
    Q_OBJECT

public:
    explicit sell_city(QWidget *parent = nullptr);
    ~sell_city();
    map* Map;int pr_num;int c_num;
    wrong_input_sign w;
    void fresh(int Pr_num){
        pr_num=Pr_num;
        ui->prnum->clear();
        ui->citysell->clear();
        ui->coins->clear();
        ui->prnum->setText((QString::number(pr_num)));
        ui->coins->setText(QString::number(Map->man[pr_num].coins));
        ui->citylist->clear();
        for(int i=0;i<32;i++){
            if(Map->blocks_type[i]==1 and Map->city_owner[i]==pr_num){
                ui->citylist->insert("城市");
                ui->citylist->insert(QString::number(i));
                ui->citylist->insert(",卖出该城市可获得");
                ui->citylist->insert(QString::number(Map->sell_city_price[i][Map->level_of_city[i]]));
                ui->citylist->insert("金币；");
            }
        }
    }


private slots:
    void on_pushButton_2_clicked();

    void on_citysell_textEdited(const QString &arg1);

    void on_pushButton_clicked();

private:
    Ui::sell_city *ui;
};

#endif // SELL_CITY_H
