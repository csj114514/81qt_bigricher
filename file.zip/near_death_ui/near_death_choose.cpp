#include "near_death_choose.h"
#include "ui_near_death_choose.h"

near_death_choose::near_death_choose(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::near_death_choose)
{
    ui->setupUi(this);
}

near_death_choose::~near_death_choose()
{
    delete ui;
}

void near_death_choose::on_sell_city_clicked()
{
    city.show();
}


void near_death_choose::on_sell_factory_clicked()
{
    factory.show();
}


void near_death_choose::on_get_money_from_bank_clicked()
{
    bank.show();
}


void near_death_choose::on_close_clicked()
{
    if(Map->man[pr_num].coins < 0){
        Map->player_die(pr_num);
    }
    this->close();
}


void near_death_choose::on_pushButton_clicked()
{
    fresh(pr_num);
}

