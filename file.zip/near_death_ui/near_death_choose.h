#ifndef NEAR_DEATH_CHOOSE_H
#define NEAR_DEATH_CHOOSE_H

#include <QWidget>
#include "ui_near_death_choose.h"
#include "near_death_ui/sell_city.h"
#include "near_death_ui/sell_factory.h"
#include "near_death_ui/get_money_from_bank.h"
#include "map.h"

namespace Ui {
class near_death_choose;
}

class near_death_choose : public QWidget
{
    Q_OBJECT

public:
    explicit near_death_choose(QWidget *parent = nullptr);
    ~near_death_choose();
    sell_city city;
    sell_factory factory;
    get_money_from_bank bank;
    map* Map;int pr_num;
    void fresh(int Pr_num){
        pr_num=Pr_num;
        if(Map->man[pr_num].coins < 0){
            ui->money_owed->setText(QString::number(0-Map->man[pr_num].coins));
        }
        else{
            ui->money_owed->setText(QString::number(0));
        }
    }

private slots:
    void on_sell_city_clicked();

    void on_sell_factory_clicked();

    void on_get_money_from_bank_clicked();

    void on_close_clicked();

    void on_pushButton_clicked();

private:
    Ui::near_death_choose *ui;
};

#endif // NEAR_DEATH_CHOOSE_H
