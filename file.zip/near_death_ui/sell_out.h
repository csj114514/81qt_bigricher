#ifndef SELL_OUT_H
#define SELL_OUT_H

#include <QWidget>
#include "near_death_ui/sell_city.h"
#include "near_death_ui/sell_factory.h"
#include "near_death_ui/get_money_from_bank.h"

namespace Ui {
class sell_out;
}

class sell_out : public QWidget
{
    Q_OBJECT

public:
    explicit sell_out(QWidget *parent = nullptr);
    ~sell_out();
    sell_city city;
    sell_factory factory;
    get_money_from_bank bank;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::sell_out *ui;
};

#endif // SELL_OUT_H
