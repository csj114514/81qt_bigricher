#include "sell_city.h"
#include "ui_sell_city.h"

sell_city::sell_city(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sell_city)
{
    ui->setupUi(this);
}

sell_city::~sell_city()
{
    delete ui;
}

void sell_city::on_pushButton_2_clicked()
{
    this->close();
}


void sell_city::on_citysell_textEdited(const QString &arg1)
{
    c_num=arg1.toInt();
}


void sell_city::on_pushButton_clicked()
{
    if(Map->city_owner[c_num]==-1 or c_num > 31 or c_num < 0){w.show();}
    else{
        Map->man[pr_num].coins+=Map->sell_city_price[c_num][Map->level_of_city[c_num]];
        Map->level_of_city[c_num]=-1;
        Map->city_owner[c_num]=-1;
        fresh(pr_num);
    }
}

