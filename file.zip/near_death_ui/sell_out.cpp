#include "sell_out.h"
#include "ui_sell_out.h"

sell_out::sell_out(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sell_out)
{
    ui->setupUi(this);
}

sell_out::~sell_out()
{
    delete ui;
}

void sell_out::on_pushButton_clicked()
{
    city.show();
}


void sell_out::on_pushButton_2_clicked()
{
    factory.show();
}


void sell_out::on_pushButton_3_clicked()
{
    bank.show();
}


void sell_out::on_pushButton_4_clicked()
{
    this->close();
}

