#ifndef GET_MONEY_FROM_BANK_H
#define GET_MONEY_FROM_BANK_H

#include <QWidget>
#include"map.h"
#include "ui_get_money_from_bank.h"
#include "ui_wrong_input_sign.h"
#include"sign_ui/wrong_input_sign.h"


namespace Ui {
class get_money_from_bank;
}

class get_money_from_bank : public QWidget
{
    Q_OBJECT

public:
    explicit get_money_from_bank(QWidget *parent = nullptr);
    ~get_money_from_bank();
    map* Map;int pr_num;int money_get;
    wrong_input_sign w;
    void fresh(int Pr_num){
        pr_num=Pr_num;
        ui->coins->clear();
        ui->coins_in_bank->clear();
        ui->pr_num->clear();
        ui->money_got->clear();
        ui->pr_num->setText(QString::number(pr_num));
        ui->coins->setText(QString::number(Map->man[pr_num].coins));
        ui->coins_in_bank->setText(QString::number(Map->man[pr_num].coins_inbank));
    }


private slots:
    void on_money_got_textEdited(const QString &arg1);

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::get_money_from_bank *ui;
};

#endif // GET_MONEY_FROM_BANK_H
