#include "prison_show.h"
#include "ui_prison_show.h"

prison_show::prison_show(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::prison_show)
{
    ui->setupUi(this);
}

prison_show::~prison_show()
{
    delete ui;
}

void prison_show::on_pushButton_clicked()
{
    this->close();
}

