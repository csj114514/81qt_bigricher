#ifndef PLAYER_INFORMATION_SHOW_H
#define PLAYER_INFORMATION_SHOW_H

#include <QWidget>
#include "ui_player_information_show.h"
#include "map.h"

namespace Ui {
class player_information_show;
}

class player_information_show : public QWidget
{
    Q_OBJECT

public:
    explicit player_information_show(QWidget *parent = nullptr);
    ~player_information_show();
    map* Map;int pr_num;
    void fresh_information(int Pr_num){
        pr_num=Pr_num;
        ui->pr_if_play->clear();
        ui->pr_city_owned->clear();
        ui->pr_coins->clear();
        ui->pr_coinsinbank->clear();
        ui->pr_num->clear();
        ui->pr_ifskipround->clear();
        ui->pr_factory_owned->clear();
        if(Map->man[pr_num].if_play){
            ui->pr_if_play->setText("是");
            ui->pr_num->setText(QString::number(Map->man[pr_num].num));
            ui->pr_coins->setText(QString::number(Map->man[pr_num].coins));
            ui->pr_coinsinbank->setText(QString::number(Map->man[pr_num].coins_inbank));
            if(Map->man[pr_num].if_skip_round)ui->pr_ifskipround->setText("是");
            else ui->pr_ifskipround->setText("否");
            for(int i=0;i<32;i++){
                if(Map->blocks_type[i]==1 and Map->city_owner[i]==pr_num){
                    ui->pr_city_owned->insert(QString::number(i));
                    ui->pr_city_owned->insert(";");
                }
            }
            for(int i=0;i<3;i++){
                for(int j=0;j<3;j++){
                    if(Map->factory_owner[i][j]==pr_num){
                        ui->pr_factory_owned->insert(QString::number(i));
                        ui->pr_factory_owned->insert(";");
                    }
                }
            }
        }
        else ui->pr_if_play->setText("否");

    }

private slots:
    void on_close_clicked();

private:
    Ui::player_information_show *ui;
};

#endif // PLAYER_INFORMATION_SHOW_H
