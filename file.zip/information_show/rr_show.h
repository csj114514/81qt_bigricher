#ifndef RR_SHOW_H
#define RR_SHOW_H

#include <QWidget>

namespace Ui {
class rr_show;
}

class rr_show : public QWidget
{
    Q_OBJECT

public:
    explicit rr_show(QWidget *parent = nullptr);
    ~rr_show();

private slots:
    void on_pushButton_clicked();

private:
    Ui::rr_show *ui;
};

#endif // RR_SHOW_H
