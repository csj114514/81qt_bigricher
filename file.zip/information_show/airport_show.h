#ifndef AIRPORT_SHOW_H
#define AIRPORT_SHOW_H

#include <QWidget>

namespace Ui {
class airport_show;
}

class airport_show : public QWidget
{
    Q_OBJECT

public:
    explicit airport_show(QWidget *parent = nullptr);
    ~airport_show();

private slots:
    void on_pushButton_clicked();

private:
    Ui::airport_show *ui;
};

#endif // AIRPORT_SHOW_H
