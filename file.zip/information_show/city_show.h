#ifndef CITY_SHOW_H
#define CITY_SHOW_H

#include <QWidget>
#include "map.h"
#include "ui_city_show.h"

namespace Ui {
class city_show;
}

class city_show : public QWidget
{
    Q_OBJECT

public:
    explicit city_show(QWidget *parent = nullptr);
    ~city_show();
    map* Map;int c_num;
    void fresh(int C_num){
        c_num=C_num;
        ui->if_owned->clear();
        ui->num_building->clear();
        ui->owner_num->clear();
        ui->pass_tax->clear();
        ui->place->clear();
        ui->price0->clear();
        ui->price1->clear();
        ui->price2->clear();
        ui->price3->clear();
        ui->place->setText(QString::number(c_num));
        ui->price0->setText(QString::number(Map->city_bulid_cost[c_num][0]));
        ui->price1->setText(QString::number(Map->city_bulid_cost[c_num][1]));
        ui->price2->setText(QString::number(Map->city_bulid_cost[c_num][2]));
        ui->price3->setText(QString::number(Map->city_bulid_cost[c_num][3]));
        if(Map->city_owner[c_num]!=-1){
            ui->if_owned->setText("是");
            ui->owner_num->setText(QString::number(Map->city_owner[c_num]));
            ui->num_building->setText(QString::number(Map->level_of_city[c_num]));
            ui->pass_tax->setText(QString::number(Map->city_pass_tax[c_num][Map->level_of_city[c_num]]));
        }
        else ui->if_owned->setText("否");
    }

private slots:
    void on_close_clicked();

private:
    Ui::city_show *ui;
};

#endif // CITY_SHOW_H
