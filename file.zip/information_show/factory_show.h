#ifndef FACTORY_SHOW_H
#define FACTORY_SHOW_H

#include <QWidget>
#include "map.h"
#include "ui_factory_show.h"

namespace Ui {
class factory_show;
}

class factory_show : public QWidget
{
    Q_OBJECT

public:
    explicit factory_show(QWidget *parent = nullptr);
    ~factory_show();
    map* Map;int f_num;
    void fresh(int F_num){
        f_num=F_num;// 为 0，1，2中的一个
        ui->place->clear();
        ui->price->clear();
        ui->pass_tax->clear();
        ui->owner0->clear();
        ui->owner1->clear();
        ui->owner2->clear();
        ui->place->setText(QString::number(Map->factory_place[f_num]));
        ui->price->setText(QString::number(Map->factory_buy_cost));
        ui->pass_tax->setText(QString::number(Map->factory_pass_tax));
        if(Map->factory_owner[f_num][0]!=-1){
            ui->owner0->setText(QString::number(Map->factory_owner[f_num][0]));
        }
        if(Map->factory_owner[f_num][1]!=-1){
            ui->owner1->setText(QString::number(Map->factory_owner[f_num][1]));
        }
        if(Map->factory_owner[f_num][2]!=-1){
            ui->owner2->setText(QString::number(Map->factory_owner[f_num][2]));
        }
    }

private slots:
    void on_close_clicked();

private:
    Ui::factory_show *ui;
};

#endif // FACTORY_SHOW_H
