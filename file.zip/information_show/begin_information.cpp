#include "begin_information.h"
#include "ui_begin_information.h"

begin_information::begin_information(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::begin_information)
{
    ui->setupUi(this);
}

begin_information::~begin_information()
{
    delete ui;
}

void begin_information::on_pushButton_clicked()
{
    this->close();
}

