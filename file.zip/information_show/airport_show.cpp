#include "airport_show.h"
#include "ui_airport_show.h"

airport_show::airport_show(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::airport_show)
{
    ui->setupUi(this);
}

airport_show::~airport_show()
{
    delete ui;
}

void airport_show::on_pushButton_clicked()
{
    this->close();
}

