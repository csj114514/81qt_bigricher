#include "bank.h"
#include "ui_bank.h"

bank::bank(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::bank)
{
    ui->setupUi(this);
}

bank::~bank()
{
    delete ui;
}

void bank::on_close_clicked()
{
    this->close();
}

