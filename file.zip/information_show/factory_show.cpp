#include "factory_show.h"
#include "ui_factory_show.h"

factory_show::factory_show(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::factory_show)
{
    ui->setupUi(this);
}

factory_show::~factory_show()
{
    delete ui;
}

void factory_show::on_close_clicked()
{
    this->close();
}

