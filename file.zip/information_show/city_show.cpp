#include "city_show.h"
#include "ui_city_show.h"

city_show::city_show(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::city_show)
{
    ui->setupUi(this);
}

city_show::~city_show()
{
    delete ui;
}

void city_show::on_close_clicked()
{
    this->close();
}

