#ifndef BEGIN_INFORMATION_H
#define BEGIN_INFORMATION_H

#include <QWidget>

namespace Ui {
class begin_information;
}

class begin_information : public QWidget
{
    Q_OBJECT

public:
    explicit begin_information(QWidget *parent = nullptr);
    ~begin_information();

private slots:
    void on_pushButton_clicked();

private:
    Ui::begin_information *ui;
};

#endif // BEGIN_INFORMATION_H
