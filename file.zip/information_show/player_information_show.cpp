#include "player_information_show.h"
#include "ui_player_information_show.h"

player_information_show::player_information_show(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::player_information_show)
{
    ui->setupUi(this);
}

player_information_show::~player_information_show()
{
    delete ui;
}

void player_information_show::on_close_clicked()
{
    this->close();
}

