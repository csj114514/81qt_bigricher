#include "re_show.h"
#include "ui_re_show.h"

re_show::re_show(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::re_show)
{
    ui->setupUi(this);
}

re_show::~re_show()
{
    delete ui;
}

void re_show::on_pushButton_clicked()
{
    this->close();
}

