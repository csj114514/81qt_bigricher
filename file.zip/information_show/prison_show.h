#ifndef PRISON_SHOW_H
#define PRISON_SHOW_H

#include <QWidget>

namespace Ui {
class prison_show;
}

class prison_show : public QWidget
{
    Q_OBJECT

public:
    explicit prison_show(QWidget *parent = nullptr);
    ~prison_show();

private slots:
    void on_pushButton_clicked();

private:
    Ui::prison_show *ui;
};

#endif // PRISON_SHOW_H
