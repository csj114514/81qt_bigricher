#ifndef RE_SHOW_H
#define RE_SHOW_H

#include <QWidget>

namespace Ui {
class re_show;
}

class re_show : public QWidget
{
    Q_OBJECT

public:
    explicit re_show(QWidget *parent = nullptr);
    ~re_show();

private slots:
    void on_pushButton_clicked();

private:
    Ui::re_show *ui;
};

#endif // RE_SHOW_H
