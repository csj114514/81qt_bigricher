#include "rr_show.h"
#include "ui_rr_show.h"

rr_show::rr_show(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rr_show)
{
    ui->setupUi(this);
}

rr_show::~rr_show()
{
    delete ui;
}

void rr_show::on_pushButton_clicked()
{
    this->close();
}

