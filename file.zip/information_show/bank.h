#ifndef BANK_H
#define BANK_H

#include <QWidget>
#include "map.h"
#include "ui_bank.h"

namespace Ui {
class bank;
}

class bank : public QWidget
{
    Q_OBJECT

public:
    explicit bank(QWidget *parent = nullptr);
    ~bank();
    map* Map;
    void fresh(){
        ui->coins0->clear();
        ui->bank0->clear();
        ui->coins1->clear();
        ui->bank1->clear();
        ui->coins2->clear();
        ui->bank2->clear();
        ui->coins3->clear();
        ui->bank3->clear();
        if(Map->man[0].if_play){
            ui->coins0->setText(QString::number(Map->man[0].coins));
            ui->bank0->setText(QString::number((Map->man[0]).coins_inbank));
        }
        if(Map->man[1].if_play){
            ui->coins1->setText(QString::number(Map->man[1].coins));
            ui->bank1->setText(QString::number((Map->man[1]).coins_inbank));
        }
        if(Map->man[2].if_play){
            ui->coins2->setText(QString::number(Map->man[2].coins));
            ui->bank2->setText(QString::number((Map->man[2]).coins_inbank));
        }
        if(Map->man[3].if_play){
            ui->coins3->setText(QString::number(Map->man[3].coins));
            ui->bank3->setText(QString::number((Map->man[3]).coins_inbank));
        }
    }

private slots:
    void on_close_clicked();

private:
    Ui::bank *ui;
};

#endif // BANK_H
